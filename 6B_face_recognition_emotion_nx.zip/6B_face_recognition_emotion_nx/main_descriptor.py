# -*- coding: utf-8 -*-
"""
Created on Fri May 15 08:57:37 2020

@author: ChingyingHuang
"""

#import numpy as np
#import cv2
#import tkinter as tk
##import Image, ImageTk
#import PIL.Image, PIL.ImageTk
#
#
##Set up GUI
#window = tk.Tk()  #Makes main window
#window.wm_title("Digital Microscope")
#window.config(background="#FFFFFF")
#
##Graphics window
#imageFrame = tk.Frame(window, width=600, height=500)
#imageFrame.grid(row=0, column=0, padx=10, pady=2)
#
##Capture video frames
#lmain = tk.Label(imageFrame)
#lmain.grid(row=0, column=0)
#cap = cv2.VideoCapture(0)
##while(cap.isOpened()):
#
# 
#    
#def show_frame():
#    _, frame = cap.read()
#    frame = cv2.flip(frame, 1)
#    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
#    img = PIL.Image.fromarray(cv2image)
#    imgtk = PIL.ImageTk.PhotoImage(image=img)
#    lmain.imgtk = imgtk
#    lmain.configure(image=imgtk)
#    lmain.after(10, show_frame)
#    
##    btn = tk.Button(window, text="Snapshot!", command=CloInfo)
##    btn.pack(fill="both", expand=True, padx=10, pady=10)
##    def CloInfo():
##        cv2.imencode('.jpg', frame)[1].tofile('123.jpg')
###        fp = my.glob("123.jpg")
##    button1 =tk.Button(window, text='Take a photo', command=CloInfo)
##    button1.grid(row=2, column=2)  
#   
#       
#
##Slider window (slider controls stage position)
#sliderFrame = tk.Frame(window, width=600, height=100)
#sliderFrame.grid(row = 600, column=0, padx=10, pady=2)
#
#
#
#show_frame()  #Display 2
#window.mainloop()  #Starts GUI
#--------------------------------------------------------------------
#import numpy as np
#import cv2
#import tkinter as tk
#import PIL.Image, PIL.ImageTk
#
##Set up GUI
#window = tk.Tk()  #Makes main window
#window.wm_title("Digital Microscope")
#window.config(background="#FFFFFF")
#
##Graphics window
#imageFrame = tk.Frame(window, width=600, height=500)
#imageFrame.grid(row=0, column=0, padx=10, pady=2)
#
##Capture video frames
#
#cap = cv2.VideoCapture(0)
#
#def show_frame():
#       _, frame = cap.read()
#       frame = cv2.flip(frame, 1)
#       cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
#       img = PIL.Image.fromarray(cv2image)
#       imgtk = PIL.ImageTk.PhotoImage(image=img)
#       display1.imgtk = imgtk #Shows frame for display 1
#       display1.configure(image=imgtk)
#       display2.imgtk = imgtk #Shows frame for display 2
#       display2.configure(image=imgtk)
#       window.after(10, show_frame) 
#
#display1 = tk.Label(imageFrame)
#display1.grid(row=1, column=0, padx=10, pady=2)  #Display 1
#display2 = tk.Label(imageFrame)
#display2.grid(row=0, column=0) #Display 2
#
##Slider window (slider controls stage position)
#sliderFrame = tk.Frame(window, width=600, height=100)
#sliderFrame.grid(row = 600, column=0, padx=10, pady=2)
#
#show_frame() #Display
#window.mainloop()  #Starts GUI
#-------------------------------------------------------------------------
from PIL import Image, ImageTk
import tkinter as tk
import argparse
import datetime
import cv2
import os

import php
#import sys
from skimage import io
import dlib
import numpy
#import msvcrt



my = php.kit()

# 人臉68特徵點模型路徑
predictor_path = "shape_predictor_68_face_landmarks.dat"
# 人臉辨識模型路徑
face_rec_model_path = "dlib_face_recognition_resnet_model_v1.dat"
# 載入人臉檢測器
detector = dlib.get_frontal_face_detector()
# 載入人臉特徵點檢測器
sp = dlib.shape_predictor(predictor_path)
# 載入人臉辨識檢測器
facerec = dlib.face_recognition_model_v1(face_rec_model_path)


#savepath="rec\\pic1"
#np_dir = "rec\\numpy_muti"

savepath="out5_14"
np_dir = "out5_14"



class Application:
    
    def __init__(self, output_path = "./"):        
       
       """ Initialize application which uses OpenCV + Tkinter. It displays
           a video stream in a Tkinter window and stores current snapshot on disk """
       self.vs = cv2.VideoCapture(0) # capture video frames, 0 is your default video camera
       self.output_path = output_path  # store output path
       self.current_image = None  # current image from the camera
#       self.root = tk.Toplevel()
       self.root = tk.Tk()  # initialize root window
       self.root.title("Create faces")  # set window title
       # self.destructor function gets fired when the window is closed
       self.root.protocol('WM_DELETE_WINDOW', self.destructor)
       
       l = tk.Label(self.root, bg='pink', width=20, text='新增人臉').pack()
       
       labName = tk.Label(self.root, text = 'VIP:', justify = tk.RIGHT, width = 20)
       labName.pack()
       
    
       self.varName = tk.StringVar()
       self.varName.set('')
       self.entName = tk.Entry(self.root, width = 20, textvariable = self.varName)
       self.entName.pack()
       
       # create a button, that when pressed, will take the current frame and save it to file
       btn = tk.Button(self.root, width = 20, text="Snapshot!", command=self.take_snapshot)
       btn.pack()#,side='bottom'        fill="both", expand=True, padx=10, pady=10
       
       
       btn_can = tk.Button(self.root, width = 20, text="Save it!", command=self.take_Savetonum)
       btn_can.pack()#,side='bottom' fill="both", expand=True, padx=10, pady=10
       
       self.lstStudent = tk.Listbox(self.root, width=185)
       self.lstStudent.pack(padx=10, pady=10,side='bottom')
       
       self.panel = tk.Label(self.root)  # initialize image panel
       self.panel.pack(padx=10, pady=10,side='left')
       
       self.panel1 = tk.Label(self.root)  # initialize image panel
       self.panel1.pack(padx=10, pady=10,side='right')
    
       
       
      
       
       # start a self.video_loop that constantly pools the video sensor
           # for the most recently read frame
       self.video_loop()
    def video_loop(self):
        
        """ Get frame from the video stream and show it in Tkinter """
        ok, frame = self.vs.read()  # read frame from video stream
        if ok:  # frame captured without any errors
            cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)  # convert colors from BGR to RGBA
            self.current_image = Image.fromarray(cv2image)  # convert image for PIL
         
            
            imgtk = ImageTk.PhotoImage(image=self.current_image)  # convert image for tkinter
            self.panel.imgtk = imgtk  # anchor imgtk so it does not be deleted by garbage-collector
            self.panel.config(image=imgtk)  # show the image
            self.root.after(30, self.video_loop)  # call the same function after 30 milliseconds
           
    
        
    def take_Savetonum(self):
         
        ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") # grab the current timestamp
#        ts = self.entName.get() # grab the current timestamp
#        filename ="{}.jpg".format(ts)
           
        filename ="{}.jpg".format(ts)  # construct filename
        p = os.path.join(np_dir,self.entName.get()+"#"+ filename)  # construct output path  self.output_path     
        self.snapimage.convert("RGB").save(p, "JPEG")  # save image as jpeg file   
    
        print("[INFO] saved {}".format(p))
        self.result = '新增影像' + self.entName.get()+"#"+ filename
        self.lstStudent.insert(0,self.result)
        
      
#        fp = my.glob(savepath+"\\"+self.entName.get()+"#"+filename+".jpg")
        f = np_dir+"\\"+self.entName.get()+"#"+filename
           
#        descriptors = []       
   
#        base = os.path.basename(f)
        
        mn=self.entName.get()+"#"+ts
#        print(mn)
#        mn = my.mainname(f)
        
        op_txt = np_dir+"\\"+mn
        
#        print(op_txt)
#        if my.is_file(op_txt+".npy") == True:
#            continue
                    
        img = io.imread(f)
        dets = detector(img, 1)
        for k, d in enumerate(dets):
            shape = sp(img, d)
            face_descriptor = facerec.compute_face_descriptor(img, shape)
            v = numpy.array(face_descriptor)
            numpy.save(op_txt,v)
            
            
            self.result = '新增特徵' + f+"_"+op_txt
            self.lstStudent.insert(0,self.result)
        
        
        
        
    def take_snapshot(self):
        """ Take snapshot and save it to the file """           
        self.snapimage=self.current_image   
        imgtk = ImageTk.PhotoImage(image=self.snapimage)  # convert image for tkinter
        self.panel1.imgtk = imgtk  # anchor imgtk so it does not be deleted by garbage-collector
        self.panel1.config(image=imgtk)  # show the image
           
        

    def destructor(self):
        """ Destroy the root object and release all resources """
        print("[INFO] closing...")
        self.root.destroy()
        self.vs.release()  # release web camera
        cv2.destroyAllWindows()  # it is not mandatory in this application

# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-o", "--output", default="./",
       help="path to output directory to store snapshots (default: current folder")
args = vars(ap.parse_args())

# start the app
print("[INFO] starting...")
pba = Application(args["output"])
pba.root.mainloop()
