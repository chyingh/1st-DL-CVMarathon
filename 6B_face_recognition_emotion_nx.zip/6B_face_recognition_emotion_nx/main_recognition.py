# -*- coding: utf-8 -*-
"""
Created on Fri May 15 08:57:37 2020

@author: ChingyingHuang
"""

#-------------------------------------------------------------------------
from PIL import Image, ImageTk,ImageDraw, ImageFont
import tkinter as tk
import argparse
import datetime
import cv2
import os
import php
#import sys
#from skimage import io
import dlib
import numpy
#import msvcrt
#import imutils
#import time
from keras.models import load_model
import pyttsx3


my = php.kit()
engine = pyttsx3.init()
startTime = datetime.datetime.now()



emotion_classifier = load_model(
        'classifier/emotion_models/simple_CNN.530-0.65.hdf5')

np_dir = "./rec/result"
#faces_numpy_folder_path = "./rec/numpy_muti"
faces_numpy_folder_path = "./out5_14"#rec/numpy_ch"

facerec = dlib.face_recognition_model_v1("dlib_face_recognition_resnet_model_v1.dat")# 載入人臉辨識檢測器 # 人臉辨識模型
detector = dlib.get_frontal_face_detector()# 載入人臉檢測器
predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')# 載入人臉特徵點檢測器 人臉68特徵點模型

descriptors = []
candidate = []

for f in my.glob(faces_numpy_folder_path+"\\*.npy"):
    base = os.path.basename(f)
    candidate.append(os.path.splitext(base)[0])
    v = numpy.load(f)
    descriptors.append(v)
#cap = cv2.VideoCapture(0)
#fps = cap.get(cv2.CAP_PROP_FPS)
#print("Frames per second using video.get(cv2.CAP_PROP_FPS) : {0}".format(fps))
#
#cap.set(cv2. CAP_PROP_FRAME_WIDTH, 320)
#cap.set(cv2. CAP_PROP_FRAME_HEIGHT, 240)


fp = open("filename.txt", "a")

class Application:
    
    def __init__(self, output_path = "./"):        
       self.step_while = 0;
       """ Initialize application which uses OpenCV + Tkinter. It displays
           a video stream in a Tkinter window and stores current snapshot on disk """
       self.vs = cv2.VideoCapture(0) # capture video frames, 0 is your default video camera
       self.output_path = output_path  # store output path
       self.current_image = None  # current image from the camera
#       self.root = tk.Toplevel()
       self.root = tk.Tk()  # initialize root window
       self.root.title("Face recognition")  # set window title
       # self.destructor function gets fired when the window is closed
       self.root.protocol('WM_DELETE_WINDOW', self.destructor)
       
       self.x1=0
       self.last_rec_name=""
       self.l = tk.Label(self.root, bg='Thistle', width=20, text='人臉心情辨識打卡系統').pack()      
        
       self.rootface_rec_signin = tk.IntVar()
       self.rootface_rec_signin.set(0)       # 預設值0=未報到
       face_rec = tk.Checkbutton(self.root, text='人臉辨識', variable=self.rootface_rec_signin,onvalue=1, offvalue=0)
       face_rec.place(x=20, y=30, width=100, height=20)
        
       self.rootface_emo_signin = tk.IntVar()
       self.rootface_emo_signin.set(0)       # 預設值0=未報到
       face_emo = tk.Checkbutton(self.root, text='心情辨識', variable=self.rootface_emo_signin,onvalue=1, offvalue=0)
       face_emo.place(x=120, y=30, width=100, height=20)
        
       self.rootface_say_signin = tk.IntVar()
       self.rootface_say_signin.set(0)       # 預設值0=未報到
       face_say = tk.Checkbutton(self.root, text='心情小語', variable=self.rootface_say_signin,onvalue=1, offvalue=0)
       face_say.place(x=220, y=30, width=100, height=20)

#       labName = tk.Label(self.root, text = 'VIP:', justify = tk.RIGHT, width = 20)
#       labName.pack()
#       
#    
#       self.varName = tk.StringVar()
#       self.varName.set('')
#       self.entName = tk.Entry(self.root, width = 20, textvariable = self.varName)
#       self.entName.pack()
       
#       # create a button, that when pressed, will take the current frame and save it to file
#       btn = tk.Button(self.root, width = 20, text="Snapshot!", command=self.take_snapshot)
#       btn.pack()#,side='bottom'        fill="both", expand=True, padx=10, pady=10
#       
#       
#       btn_can = tk.Button(self.root, width = 20, text="Save it!", command=self.take_Savetonum)
#       btn_can.pack()#,side='bottom' fill="both", expand=True, padx=10, pady=10
       
       self.lstStudent = tk.Listbox(self.root, width=90)
       self.lstStudent.pack(padx=10, pady=10,side='bottom')
       
       self.panel = tk.Label(self.root)  # initialize image panel
       self.panel.pack(padx=10, pady=10,side='left')       
      
    
       
       # start a self.video_loop that constantly pools the video sensor
           # for the most recently read frame
       self.video_loop()
    def video_loop(self):
        self.emotion_labels = {
                0: 'angry',
                1: 'disgust',
                2: 'fear',
                3: 'happy',
                4: 'sad',
                5: 'surprise',
                6: 'neutral'
            }
#        self.emotion_labels = {
#                0: '覺得森氣氣',
#                1: '覺得不舒服',
#                2: '覺得怕怕',
#                3: '覺得開勳',
#                4: '覺得哭哭',
#                5: '覺得驚嚇',
#                6: '覺得沒什麼'
#            }
        def cv2ImgAddText(frame, text, left, top, textColor, textSize):
            if (isinstance(frame, numpy.ndarray)):
                frame = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            draw = ImageDraw.Draw(frame)
            fontText = ImageFont.truetype(
                    "font/simsun.ttc", textSize, encoding="utf-8")
            draw.text((left, top), text, textColor, font=fontText)
            return cv2.cvtColor(numpy.asarray(frame), cv2.COLOR_RGB2BGR)
        """ Get frame from the video stream and show it in Tkinter """
#        while(self.vs.isOpened()):
        ok, frame = self.vs.read()  # read frame from video stream
        
        if ok:  # frame captured without any errors
                       
            
            
            self.step_while=self.step_while+1
            if self.step_while>60:
                self.x1=0
                self.last_rec_name = ""
                self.step_while = 0  
                
            if self.step_while % 1==0: 
                print(self.step_while)
                dist = []
                face_rects, self.scores, idx = detector.run(frame, 0)
                for i, d in enumerate(face_rects):
                    self.x1 = d.left()
                    self.y1 = d.top()
                    self.x2 = d.right()
                    self.y2 = d.bottom()
                    cv2.rectangle(frame, (self.x1, self.y1), (self.x2, self.y2), ( 0, 255, 0), 2, cv2. LINE_AA)
                    landmarks_frame = cv2.cvtColor(frame, cv2. COLOR_BGR2RGB)
                    shape = predictor(landmarks_frame, d)
                    face_descriptor = facerec.compute_face_descriptor(frame, shape)
                    d_test = numpy.array(face_descriptor)
                    for j in descriptors:
                        dist_ = numpy.linalg.norm(j - d_test)
                        dist.append(dist_)
                    c_d = dict( zip(candidate,dist))
                    self.cd_sorted = sorted(c_d.items(), key=lambda kv: kv[1])
                    if self.cd_sorted[0][1]<0.4:#0.4
                        self.rec_name_dist = self.cd_sorted[0][1]
                        self.rec_name = self.cd_sorted[0][0]
                        m = my.explode("#",self.rec_name)
                        self.last_rec_name = m[0]
                        self.last_rec_name = self.last_rec_name.capitalize()
            
                        self.text = " %2.2f ( %d )" % (self.scores[i], idx[i])
                        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                        gray_face = gray[(self.y1):(self.y1 + self.y2), (self.x1):(self.x1 + self.x2)]
                        try:                                               
                            
                            gray_face = cv2.resize(gray_face, (48, 48))
                            gray_face = gray_face / 255.0
                            gray_face = numpy.expand_dims(gray_face, 0)
                            gray_face = numpy.expand_dims(gray_face, -1)
    #                            self.emotion_scorce=emotion_classifier.predict(gray_face)
    #                            print(emotion_scorce)
                            self.emotion_label_score = numpy.max(emotion_classifier.predict(gray_face))
                            emotion_label_arg = numpy.argmax(emotion_classifier.predict(gray_face))
                            self.emotion = self.emotion_labels[emotion_label_arg]
    #                            frame = cv2ImgAddText(frame,  self.last_rec_name+'_'+self.text+'_'+self.emotion, self.x1-30, self.y1-25, ( 0, 255, 0), 15)
                            if self.emotion_label_score>0.5:    
    #                            frame = cv2ImgAddText(frame,  self.rec_name+'_'+self.text+'_'+self.emotion, self.x1-30, self.y1-25, ( 0, 255, 0), 15)
    #                            self.result ='第'+str(self.step_while)+'frame,'+self.last_rec_name+ '覺得'+ self.emotion+'人臉分數:'+str(self.text)+ '相似最短距離:'+str(round(self.rec_name_dist,2))+'心情分數:'+str(round(self.emotion_label_score,2))
                                self.result =str(self.step_while)+self.last_rec_name+'_'+ self.emotion+'人臉分數:'+str(self.text)+ '相似距離:'+str(round(self.rec_name_dist,2))+'心情分數:'+str(round(self.emotion_label_score,2))
                                self.lstStudent.insert(0,self.result)
                                frame = cv2ImgAddText(frame, self.result, 5, self.y1-25, ( 255, 0, 0),20)
                                ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") # grab the current timestamp   
                                filename ="{}.jpg".format(ts)  # construct filename
                                p = os.path.join(np_dir,self.last_rec_name+"_"+ filename)  # construct output path  self.output_path     
                                cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)  # convert colors from BGR to RGBA
                                self.current_image = Image.fromarray(cv2image) 
                                self.current_image.convert("RGB").save(p,"JPEG")  # save image as jpeg file            
                                fp.writelines(self.result+"\n")
                                fp.flush()
                                
    
                                if emotion_label_arg ==0 :
                                    engine.say(self.last_rec_name + '早安，祝您有美好的一天')
                                elif emotion_label_arg ==1 :
                                    engine.say(self.last_rec_name + '嗨!記得吃早餐喔')
                                elif emotion_label_arg ==2 :
                                    engine.say(self.last_rec_name + '今天替你加加油')
                                elif emotion_label_arg ==3 :
                                    engine.say(self.last_rec_name + '要一值保持開心喔')
                                elif emotion_label_arg ==4 :
                                    engine.say(self.last_rec_name + '早安，期待美好的一天')                        
                                elif emotion_label_arg ==5 :
                                    engine.say(self.last_rec_name + '')
                                elif emotion_label_arg ==6 :
                                    engine.say(self.last_rec_name + ' 早!買杯咖啡喝吧')
                #                else:
                #                    engine.say(last_rec_name + '您好，您尚未成為我們的VIP，請快加入我們吧') 
                                engine.runAndWait()
        #                        print(m[0],'_',cd_sorted[0][1],'_',self.text,'_',self.emotion)
    #                            if self.x1!=0:                      
    #                                cv2.rectangle(frame, (self.x1, self.y1), (self.x2, self.y2), ( 0, 255, 0), 2, cv2. LINE_AA)
    #                            if self.last_rec_name!="":
    #                                frame = cv2ImgAddText(frame,  self.rec_name+'_'+self.text+'_'+self.emotion, self.x1-30, self.y1-25, ( 0, 255, 0), 15)
    #                                self.result ='第'+str(self.step_while)+'frame,'+self.last_rec_name+ '覺得'+ self.emotion+'人臉分數:'+str(self.text)+ '相似最短距離:'+str(self.rec_name_dist)#+'表情分:'+self.emotion_scorce
    #                                self.lstStudent.insert(0,self.result)
    #                                
    #                                p = os.path.join(np_dir,'第'+str(self.step_while)+'frame'+self.last_rec_name+ '覺得'+ self.emotion)#self.last_rec_name+"_"+ filename+self.emotion+"_"+self.emotion_label_arg)  # construct output path  self.output_path     
    #                                self.current_image.convert("RGB").save(p, "JPEG")  # save image as jpeg file 
    #                                
    #    #                                ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") # grab the current timestamp
    #    #           
    #    #                                filename ="{}.jpg".format(ts)  # construct filename
    #    #                                p = os.path.join(np_dir,self.last_rec_name+"#"+ filename)  # construct output path  self.output_path     
    #    #                                self.current_image.convert("RGB").save(p, "JPEG")  # save image as jpeg file   
    #                   
    #                                fp.writelines(self.result+"\n")
    #                                fp.flush()
                        except:
                            continue 
            
            
##                if self.x1!=0:                      
##                    cv2.rectangle(frame, (self.x1, self.y1), (self.x2, self.y2), ( 0, 255, 0), 2, cv2. LINE_AA)
#                if self.last_rec_name!="":
#                    frame = cv2ImgAddText(frame,  self.rec_name+'_'+self.text+'_'+self.emotion, self.x1-30, self.y1-25, ( 0, 255, 0), 15)
#                    self.result ='第'+str(self.step_while)+'frame,'+self.last_rec_name+ '覺得'+ self.emotion+'人臉分數:'+str(self.text)+ '相似最短距離:'+str(self.rec_name_dist)+'心情分數:'+str(self.emotion_label_score)
#                    self.lstStudent.insert(0,self.result)
#                    
#                    ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S") # grab the current timestamp   
#                    filename ="{}.jpg".format(ts)  # construct filename
#                    p = os.path.join(np_dir,self.last_rec_name+"_"+ filename)  # construct output path  self.output_path     
##                    frame.save(p, "JPEG")
#                    self.current_image.convert("RGB").save(p,"JPEG")  # save image as jpeg file   
#    #         
#    
#        #                print(self.step_while)
#                    
#        #                lines = ["frame:", str(self.step_while),", 人臉:", self.text, ", emotion:"]#,self.rec_name,":", self.rec_name_scores]
#        #                lines = ["frame:"]
#                    fp.writelines(self.result+"\n")
#                    fp.flush()
#                   
  
            
            cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)  # convert colors from BGR to RGBA
            self.current_image = Image.fromarray(cv2image)  # convert image for PIL
#            self.mmm=self.current_image           
            
            imgtk = ImageTk.PhotoImage(image=self.current_image)  # convert image for tkinter
            self.panel.imgtk = imgtk  # anchor imgtk so it does not be deleted by garbage-collector
            self.panel.config(image=imgtk)  # show the image
            self.root.after(30, self.video_loop)  # call the same function after 30 milliseconds           
    
  
      

    def destructor(self):
        """ Destroy the root object and release all resources """
        print("[INFO] closing...")
        self.root.destroy()
        self.vs.release()  # release web camera
        cv2.destroyAllWindows()  # it is not mandatory in this application

# construct the argument parse and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-o", "--output", default="./",
       help="path to output directory to store snapshots (default: current folder")
args = vars(ap.parse_args())

# start the app
print("[INFO] starting...")
pba = Application(args["output"])
pba.root.mainloop()
fp.close()